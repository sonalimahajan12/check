package com.kafka;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Priority;

import org.apache.kafka.common.metrics.KafkaMetric;
import org.apache.kafka.common.metrics.MetricsReporter;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Log
public class KafkaSelfMetric implements MetricsReporter {

	
	private final Logger log = (Logger) LoggerFactory.getLogger(this.getClass());
    private static final String PREFIX = "kafka-";
    private static final List<String> EXCLUDES = Arrays.asList(
            "version",
            "commit-id"
    );

    @Override
    public void init(List<KafkaMetric> list) {
        log.debug("init: {}", list);

        list.forEach(this::registerMetric);
    }

    @Override
    public void metricChange(KafkaMetric kafkaMetric) {
        log.debug("metricChange: {}", kafkaMetric.metricName());

        registerMetric(kafkaMetric);
    }

    private void registerMetric(KafkaMetric kafkaMetric) {
        if (EXCLUDES.contains(kafkaMetric.metricName().name())) {
            log.debug("Excluding metric: {}", kafkaMetric.metricName());
            return;
        }

        final List<Tag> tags = Stream.concat(
                kafkaMetric.metricName().tags().entrySet().stream()
                        .map(entry -> Tag.of(entry.getKey(), entry.getValue())),
                Stream.of(Tag.of("group", kafkaMetric.metricName().group()))
        )
                .collect(Collectors.toList());

        SpringHook.meterRegistry.gauge(PREFIX+kafkaMetric.metricName().name(), tags,
                kafkaMetric, value -> {
                    final Object rawValue = ((KafkaMetric) value).metricValue();
                    if (rawValue instanceof Number) {
                        final double v = ((Number) rawValue).doubleValue();
                        if (Double.isInfinite(v) || Double.isNaN(v)) {
                            return 0;
                        }
                        return v;
                    }
                    else {
                        log.trace("Metric {} provided non-numerical value", kafkaMetric.metricName());
                        return 0;
                    }
                });
    }

    @Override
    public void metricRemoval(KafkaMetric kafkaMetric) {
        log.debug("metricRemoval: {}", kafkaMetric.metricName());

    }

    @Override
    public void close() {
        log.debug("close");
    }

    @Override
    public void configure(Map<String, ?> map) {
        log.debug("configure: {}", map);
    }

    @Component @Priority(10)
    public static class SpringHook {
        static MeterRegistry meterRegistry;

        @Autowired
        public SpringHook(MeterRegistry meterRegistry) {
            SpringHook.meterRegistry = meterRegistry;
        }
    }

}
