package com.kafka;

import java.io.IOException;
import java.util.function.Consumer;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/consumer")
public class KafkaController {

    

    

	/*
	 * @GetMapping(value = "/consume") public void
	 * sendMessageToKafkaTopic(@RequestParam("message") String message) throws
	 * IOException { //System.out.println("123"); this.consumer.consume(message);
	 * //this.consumer.consume(); }
	 */
	/*
	 * @RequestMapping(value = "/consumeMessage/{topic}", method = {
	 * RequestMethod.GET }) public String consumeMessage(@PathVariable String topic)
	 * {
	 * 
	 * String topicName = "topic-devinline-1"; String groupName = "mygroup";
	 * Properties props = new Properties(); props.put("bootstrap.servers",
	 * "localhost:9092"); props.put("group.id", groupName);
	 * props.put("key.deserializer",
	 * "org.apache.kafka.common.serialization.StringDeserializer");
	 * props.put("value.deserializer",
	 * "org.apache.kafka.common.serialization.StringDeserializer");
	 * 
	 * KafkaConsumer<String, String> consumer = null; try { consumer = new
	 * KafkaConsumer<String, String>(props);
	 * consumer.subscribe(Arrays.asList(topicName)); while (true) {
	 * ConsumerRecords<String, String> records = consumer.poll(1); for
	 * (ConsumerRecord<String, String> record : records) { System.out.
	 * printf("Message received -> partition = %d, offset = %d, key = %s, value = %s\n"
	 * , record.partition(), record.offset(), record.key(), record.value()); } } }
	 * catch (Exception ex) { ex.printStackTrace(); } finally { consumer.close(); }
	 * 
	 * 
	 * 
	 * return "success"; }
	 */  
   
	  @GetMapping(value = "/consumeMessage/{topic}") 
	  public String sendMessageToKafkaTopic(@PathVariable String topic) throws
	  IOException { 
		  //System.out.println("123"); 
		
		  MyConsumer consumer = new MyConsumer();
		  consumer.consume(topic);
		  
		  return "success";
	  }
	  //@GetMapping(value = "/consumeMessage/metrics") 
	
    
}