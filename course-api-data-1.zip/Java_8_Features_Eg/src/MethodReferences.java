import java.lang.reflect.Array;
import java.util.Arrays;
interface smart
{
	Hello display(String say);
}
class Hello
{
	Hello(String say)
	{
		System.out.print(say);
	}
}
//interface instanceEg
//{
//	public void display();
//}
class MethodReferences
{
//	public void mymethod()
//	{
//		System.out.print("I'm outside main bit in class ");
//	}
	public static void main(String[] args) 
	{
		smart obj=Hello::new;
		obj.display("hello world");
		
		
		
//		String[] str= {"Sonali ","Mahajan ","National ","Institute ","Of ","Technology "};
//		Arrays.sort(str,String::compareToIgnoreCase);
//		for(String name:str)
//			System.out.print(name);
		
		
//		MethodReferences obj=new MethodReferences();
//		instanceEg obj1=obj::mymethod;
//		obj1.display();

	}
}

