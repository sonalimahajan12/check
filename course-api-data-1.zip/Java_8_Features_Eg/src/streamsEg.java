import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class streamsEg
{
	public static void main(String[] args) 
	{
		
		
		
		
		
//		List<String> list= new ArrayList<String>();
//		list.add("Soni ");
//		list.add("Mahajan ");
//		list.add("national ");
//		List<String> list1= new ArrayList<String>();
//		list1.add("Institute ");
//		list1.add("of ");
//		list1.add("Technology ");
//		Stream<String> op=Stream.concat(list1.stream(), list.stream());
//		op.forEach(str->System.out.print(str+ " "));
		
		
		
		
//		Stream.iterate(1, i->i+1).filter(n->n%3==0).limit(10).forEach(System.out::println);
		
		
//		List<String> list= new ArrayList<String>();
//		list.add("Soni ");
//		list.add("Mahajan ");
//		list.add("national ");
//		list.add("Institute ");
//		list.add("of ");
//		list.add("Technology ");
//		long c=list.stream().filter(str->str.length()<6).count();
//		System.out.print("Count is : "+c);
	}
}
