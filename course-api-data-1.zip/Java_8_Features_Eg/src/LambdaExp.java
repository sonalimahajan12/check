import java.awt.print.Printable;
import java.util.ArrayList;
import java.util.*;

//interface simple
//{
//	public String show();
//}
//interface parameters
//{
//	public int print(int a,int b);
//}

public class LambdaExp {

	public static void main(String[] args) {
		
		List<String> list1=new ArrayList<String>(); 
		list1.add("Sonali");
		list1.add("Mahajan");
		list1.add("National");
		list1.add("Institute");
		list1.add("Of");
		list1.add("Technology");
		list1.forEach((obj) ->System.out.print(obj));
//		parameters objParameters=(int a,int b)-> a+b;
//		System.out.print("value of a  and b is : " +objParameters.print(10,20));
	
//		simple obj=()->{ return "Hello";};
//		System.out.print(obj.show());
	}

}
