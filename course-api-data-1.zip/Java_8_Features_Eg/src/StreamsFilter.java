import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class StreamsFilter
{
	public static void main(String[] args) 
	{
		List<String> list=new ArrayList<String>();
		list.add("Cat");
		list.add("Dog");
		list.add("Hen");
		list.add("Go");
		list.add("There");
		list.add("Sun");
		list.stream().filter(f->f.startsWith("H")).forEach(System.out::println);
		
		
		
//			Map<Integer,String> hMap=new HashMap<Integer,String>();
//			hMap.put(1,"Sonali ");
//			hMap.put(2," Mahajan ");
//			hMap.put(3," national ");
//			hMap.put(4," institute ");
//			hMap.put(5," Tech ");
//			hMap.forEach((key,value)->{ if(key==4) System.out.print("value of 4 is : " +value);});
//			hMap.forEach((key,value)-> { if (" Mahajan ".equals(value)) {System.out.print("Key is : "+key);}});
	}
}
