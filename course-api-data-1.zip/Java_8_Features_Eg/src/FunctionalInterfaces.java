import org.ietf.jgss.Oid;

interface smar
{
	default void show(){
		System.out.print("I'm the interface dsefault method   ");
	}
	public static void show2()
	{
		System.out.print("i'm a static metod");
	}
	void show1(String str);
}
public class FunctionalInterfaces implements smar {
	public void show1(String str)
	{
		System.out.print(" string is: "+str);
	}
	public static void main(String[] args) 
	{
		FunctionalInterfaces obj=new FunctionalInterfaces();
		obj.show();
		smar.show2();
		obj.show1("This is a string in main claas  ");
		
	}

}
