public class OddEvenThreadSeq
{
		  public static void main(String[] args)
		  {
			  SharedClass sp = new SharedClass();
			  Thread t1 = new Thread(new EvenNumProducer(sp,10));
			  Thread t2 = new Thread(new OddNumProducer(sp,10));
			  t1.start();
			  t2.start();
		  }
}
class SharedClass
{
	 boolean evenFlag = false;
 public void printEvenNum(int num)
 {
	 
	  synchronized(this)
	  {
	   while(!evenFlag)
	   {
		    try 
			    {
			     wait();
			    } 
		    catch (InterruptedException e)
			    {
			     e.printStackTrace();
			    }
	    }
   System.out.println("\nEven no is :");
   System.out.println(num);
   evenFlag = false;
   notify();
  }
 }
 public void printOddNum(int num)
 {
		  synchronized(this)
		  {
			   while(evenFlag)
			   {
			    try {
			     wait();
			    } catch (InterruptedException e) {
			     e.printStackTrace();
			    }
			    }
			   System.out.println("\nOdd no is :");
			   System.out.println(num);
			   evenFlag=true;
			   notify();
			   
		   }
 }
}
class EvenNumProducer implements Runnable
{
    SharedClass sp;
    int index;
    
    EvenNumProducer(SharedClass sp,int index)
    {
        this.sp=sp;
        this.index=index;
    }
   
    public void run()
    {
        for(int i=1;i<=index;i++)
        {
        	if(i%2==0)
            sp.printEvenNum(i);
        }   
    }   
}
class OddNumProducer implements Runnable
{
    SharedClass sp;
    int index;
    OddNumProducer(SharedClass sp,int index)
    {
        this.sp=sp;
        this.index=index;
    }
    public void run()
    {
        for(int i=1;i<=index;i++)
        {
        	if(i%2!=0)
            sp.printOddNum(i);
        }
    }
}