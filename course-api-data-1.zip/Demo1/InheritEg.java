class Bicycle
{
	public int gear;
	public int speed;
	public Bicycle(int gear,int speed)
	{
		this.gear=gear;
		this.speed=speed;
	}
	public void applybrakes(int decrement)
	{
		speed-=decrement;
	}
	public void speedup(int increment)
	{
		speed+=increment;
	}
	public String tostring()
	{
		return("No of gears are: " + gear+ "speed is: " +speed);
	}
}
class MountainBike extends Bicycle
{
	public int seatheight;
	public MountainBike(int gear,int speed,int startHeight)
	{
		super(gear,speed);
		seatheight=startHeight;
	}
	public void setheight(int newvalue)
	{
		seatheight=newvalue;
	}
	public String tostring()
	{
		return(super.tostring()+ "seat height is : " +seatheight);
	}
}
public class InheritEg
{
	public static void main(String[] args)
	{
		MountainBike mc=new MountainBike(3,100,25);
		System.out.print(mc.tostring());
	}
}