import java.util.*;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
public class futureCall
{
    public static ExecutorService executorService = Executors.newFixedThreadPool(4);
    
	public static void main(String[] args) {
		System.out.println("Hello World");
		List<List<Integer>> subList = new ArrayList<>();
		
		List<Integer> lt1 = new ArrayList<>(Arrays.asList(1,2,3));
	    List<Integer> lt2 = new ArrayList<>(Arrays.asList(11,22,33));
	    subList.add(lt1);
	    subList.add(lt2);
	    
//        demoSubList(subList);
        demo(subList);
  
	}
//	public static void demoSubList(List<List<Integer>> subList){
//        subList.forEach(list -> {
//            Callable<Void> callable = new Callable<Void>() {
//                public Void call() {
//                    demoMethodSubList(list);
//                    return null;
//                }
//            };
//            Future<Void> future = executorService.submit(callable);
//            try {
//                future.get();
//            } catch (Exception e) {
//                
//            }
//        });
//    }
//    public static void demoMethodSubList(List<Integer> lt) {
//        System.out.println("List value: "+ lt);
//    }
//	
	 public static void demo(List<List<Integer>> subList){
        subList.forEach(list -> {
            Callable<Void> callable = new Callable<Void>() {
                public Void call() {
                    list.forEach(list -> {
                         // WRITE YOUR METHOD CALL HERE.
                         demoMethod(list);
                    });
                    return null;
                }
            };
            Future<Void> future = executorService.submit(callable);
            try {
                future.get();
            } catch (Exception e) {
                
            }
        });
    }
    public static void demoMethod(int lt) {
        System.out.println("List value: "+ lt);
    }

}