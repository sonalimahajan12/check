public class Number
{
	int Number=10;
	public static void main(String[] args)
	{
		Number Number=new Number();
		System.out.println(Number);
		System.out.println(Number.Number);
	}
}