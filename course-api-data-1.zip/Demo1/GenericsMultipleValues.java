class test1<T,U>
{
	T obj1;
	U obj2;
	public test1(T obj1,U obj2)
	{
		this.obj1=obj1;
		this.obj2=obj2;
	}
	public void printS()
	{
		System.out.print(obj1);
		System.out.print(obj2);
	}
}
public class GenericsMultipleValues
{
	public static void main(String[] args)
	{
		test1 <String,Integer> Sobj=new test1 <String,Integer>("Sonali ",14);
		Sobj.printS();
	}
}
