import java.lang.*;
class ScpEx
{
	public static void main(String[] args)
	{
		StringBuffer sbf=new StringBuffer("SonaliMahajan");
		System.out.println(" The String is " +sbf);
		sbf.appendCodePoint(66);
		System.out.println("ASCII Code is " +sbf);
	}
}