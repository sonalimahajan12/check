class test<T>
{
	T obj;
	test(T obj)
	{
		this.obj=obj;
	}
	public T getObject()
	{
		return this.obj;
	}
}
public class genericsEg {
		public static void main(String[] args)
		{
			test <Integer> obj=new test<Integer>(15);
			System.out.print(obj.getObject());
			test <String> sobj=new test <String>(" Sonali Mahajan ");
			System.out.print(sobj.getObject());
		}
}
