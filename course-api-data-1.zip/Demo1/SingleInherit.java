import java.util.*;
import java.lang.*;
import java.io.*;
class first
{
	public void prints()
	{
		System.out.print(" Sonali");
	}
}
class second extends first
{
	public void printed()
	{
		System.out.print(" Mahajan");
	}
}
public class SingleInherit
{
	public static void main(String[] args)
	{
		second obj=new second();
		obj.prints();
		obj.printed();
		obj.prints();
	}
}