import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
public class MxMinNew  implements Callable<Integer> 
{
		 private List<Integer> lst= null;
		 List<Integer> fn=new ArrayList<>();
		public static ExecutorService executorService;
		public static int numberOfParts;
		MxMinNew(List<Integer> lst)
		{
			this.lst=lst;
		}
		public MxMinNew(){}		 
		public Integer call() throws Exception {
			int m=maxFromList(lst);
	        return m;   
	    }		
	 public static void main(String[] args)
	 {
		 List<Integer> arrayList = new ArrayList<>();  
		 int n;
		 Scanner sc=new Scanner(System.in);
		 System.out.print("Enter the No of Elements in List: ");
		 n=sc.nextInt();
		 System.out.print("Enter the List: ");
		 for(Integer i=0;i<n;i++)
		 {
		         int input = sc.nextInt();
		         arrayList.add(input);
		 }
		 System.out.print("Enter No of Sublist: ");
		 numberOfParts=sc.nextInt();	 
		 //Dynamic Thread
		  executorService = Executors.newFixedThreadPool(numberOfParts);  	 
		 //Final Sub-List
		 List<List<Integer>> DividSublist = new ArrayList<>(numberOfParts);
	      int size = arrayList.size();
	      int sizePernumberOfParts = (int) Math.ceil(((double) size) / numberOfParts);
	      int leftElements = size;
	      int i = 0;
	      while (i < size && numberOfParts != 0) {
	    	  DividSublist.add((List<Integer>) arrayList.subList(i, i + sizePernumberOfParts));
	          i = i + sizePernumberOfParts;
	          leftElements = leftElements - sizePernumberOfParts;
	          sizePernumberOfParts = (int) Math.ceil(((double) leftElements) / --numberOfParts);
	       }
	      List<Integer> fList = new ArrayList<>();	  
	      //Printing SubList and calling 
			for (List<Integer> s : DividSublist) {
				System.out.println("\n Sublist is: " +s);				
				Integer mnInteger = maxFromList(s);
				fList.add(mnInteger);		
				MxMinNew nmnMxmin = new MxMinNew(s);
			}
			//Printing the Maximum from the List
			System.out.println("\nMaximum from all the Sub-lists are: " +maxFromList1(fList));	//System.out.println(" " +maxFromList1(fList));		//fList
	 }
	 public static void demo(List<Integer> dividSublist){
		 List<Future<Integer>> list = new ArrayList<Future<Integer>>();
	            Callable<Integer> callable = new MxMinNew();
	            for(int i=0; i< numberOfParts; i++)
	            {
	                Future<Integer> future = executorService.submit(callable);      
	                list.add(future);
	            }
	            List<Integer> fList = new ArrayList<>();
	            Future<Integer> future = executorService.submit(callable);
	            try
	            {
	            	for (Future<Integer> s : list) {
	    				System.out.println("\n Sublist is: " +s);				
	    				Integer mnInteger = s.get();
	    				fList.add(mnInteger);		
	    			}
	            }
	            catch (Exception e) {}	       
	    }
	 public static Integer maxFromList(List<Integer> lt) {
		 System.out.print("Maximum is : " + Collections.max(lt));
		 Integer maxOfList =Collections.max(lt); 	 	 
		 return maxOfList;
	    }
	 public static Integer maxFromList1(List<Integer> lt) {
		 Integer maxOfList =Collections.max(lt); 	  //System.out.print("Maximum is : " + Collections.max(lt));
		 return maxOfList;
	    }
	 

}


	




