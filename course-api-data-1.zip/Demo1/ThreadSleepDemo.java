
public class ThreadSleepDemo implements Runnable
{
	Thread t;
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.print(Thread.currentThread().getName() + " " + i);
		try
		{
			Thread.sleep(1000);
		}			
		catch(Exception e)
		{
			System.out.print(e);
		}
		}
	}
	public static void main(String[] args)
	{
		Thread t=new Thread(new ThreadSleepDemo());
		t.start();
		Thread t2=new Thread(new ThreadSleepDemo());
		t2.start();
	}
}



