import java.io.*;
import java.util.*;
import java.lang.*;
class A
{
	void m1()
	{
		System.out.print("Inside A's Method ");
	}
}
class B extends A
{
	void m1()
	{
		System.out.print(" Inside B's Method ");
	}
}
class C extends A
{
	void m1()
	{
		System.out.print(" Inside C's Method ");
	}
}
class DispatchUsingHierarchicalinheritance
{
	public static void main(String[] args)
	{
		A a=new A();
		B b=new B();
		C c=new C();
		A ref;
		ref=a;
		ref.m1();
		ref=b;
		ref.m1();
		ref=c;
		ref.m1();
	}
}