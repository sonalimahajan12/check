
public class ThreadExtends extends Thread
{
		public static void main(String[] args)
		{
			Thread t=Thread.currentThread();
			System.out.print("Name of thread is : " +t.getName()+ "\n");
			t.setName("Sonali");
			System.out.print("Name of thread is : " +t.getName() +"\n");
			System.out.print("Main Thread Priority : " + t.getPriority()+ "\n");
			t.setPriority(MAX_PRIORITY);
			System.out.print("Priority of the thread is: " +t.getPriority() + "\n");
			for(int i=0;i<5;i++)
				System.out.print("GFG");
			System.out.print("\n");
			ChildThread ct=new ChildThread();
			System.out.print("The priority of child is: " +ct.getPriority() +"\n");
			ct.setPriority(MIN_PRIORITY);
			System.out.print("The priority of new child is: " +ct.getPriority() +"\n");
			ct.start();
		}
}
class ChildThread extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
			System.out.print("Child Thread \n");
	}
}
