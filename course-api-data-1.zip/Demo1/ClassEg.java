import java.io.*;
public class ClassEg
{
	String name;
	String breed;
	int age;
	String color;
	public ClassEg(String name,String breed,int age,String color)
	{
		this.name=name;
		this.breed=breed;
		this.age=age;
		this.color=color;
	}
	public String getname()
	{
	 return name;	
	}
	public String getcolor()
	{
		return color;
	}
	public int getage()
	{
		return age;
	}
	public String getbreed()
	{
		return breed;
	}
	public String answer()
	{
		return("Hi my name is: " +this.getname()+ "and of breed: " +this.getbreed()+ "Color is: " 
	+this.getcolor()+ "Age is : " +this.getage());
	}
	public static void main(String[] args)
	{
		ClassEg tuffy=new ClassEg("tuffy","Lamba",25,"RED");
		System.out.println(tuffy.answer());
	}
}