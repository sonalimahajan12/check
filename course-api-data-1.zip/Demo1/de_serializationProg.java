import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Demo implements java.io.Serializable
{
	String str;
	int no;
	String name;
	Demo(String s,int n,String nm)
	{
		this.str=s;
		this.no=n;
		this.name=nm;
	}
}
class de_serializationProg
{
	public static void main(String[] args)
	{
		Demo obj=new Demo("Sonali ",101 ,"Mahajan");
		try
		{
		FileOutputStream fos=new FileOutputStream("serialfile.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(obj);
		oos.close();
		fos.close();
		System.out.print("object hasbeen serialized");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		Demo obj1=null;
		try
		{
			FileInputStream fos=new FileInputStream("serialfile.ser");
			ObjectInputStream ois=new ObjectInputStream(fos);
			obj1=(Demo)ois.readObject();
			ois.close();
			fos.close();
			System.out.print("Object has been deserialzed ");
			System.out.print(" Printing 1st: " +obj1.name);
			System.out.print(" Printing 1st: " +obj1.str);
			System.out.print(" Printing 1st: " +obj1.no);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
