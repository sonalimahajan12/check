import java.util.*;
import java.io.*;
import java.lang.*;

interface one
{
	public void print_for();
}
interface two
{
	public void print_geeks();
}
interface three extends one,two
{
	public void print_geek();
}
class child implements three
{
	public void print_geek()
	{
		System.out.print("Geeks ");
	}
	public void print_for()
	{
		System.out.print(" For ");
	}
}
class Multipleinherit
{
	public static void main(String[] args)
	{
		child obj=new child();
		obj.print_geek();
		obj.print_for();
		obj.print_geek();
	}
}