public class Constructor1
{
	private int l,b,h;
	public Constructor1()
	{
		l=10; b=20; h=5;
	}
	public Constructor1(int L,int B,int H)
	{
		l=L; b=B; h=H;
	}
	public static void main(String []args)
	{
		Constructor1 t1=new Constructor1();
		Constructor1 t2=new Constructor1(30,20,10);
	}
}