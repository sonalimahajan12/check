import java.lang.Enum;
import java.util.Scanner;
enum Color{
	RED,GREEN,BLUE;
}
public class MethodsEnum
{
	public static void main(String[] args)
	{
		Color arr[]=Color.values();
		for(Color col: arr)
		{
			System.out.println(col + "index at " + col.ordinal());
		}
		System.out.println(Color.valueOf("RED"));
	}
}
