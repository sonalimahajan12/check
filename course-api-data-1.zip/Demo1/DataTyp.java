class DataTyp
{
	public static void main(String[] args)
	{
//		boolean b=false;
//		if(b==true)
//			System.out.println("val is true");
//		Byte DataType
//		byte b=126;
//		System.out.println(b);
//		b++;
//		System.out.println(b);
//		b++;
//		System.out.println(b);
//		b++;
//		System.out.println(b);
		char i='G';
		int b=2;
		byte c=4;
		short d=56;
		double e=4.355453532;
		float f=4.7333434f;
		System.out.println("char: "+i);
		System.out.println("char: "+b);
		System.out.println("char: "+c);
		System.out.println("char: "+d);
		System.out.println("char: "+e);
		System.out.println("char: "+f);
	}
}