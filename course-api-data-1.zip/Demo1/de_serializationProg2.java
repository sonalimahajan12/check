import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class emp implements java.io.Serializable
{
	transient int a;
	static int b;
	String name;
	int age;
	emp(String name,int age,int a,int b)
	{
		this.name=name;
		this.age=age;
		this.a=a;
		this.b=b;
	}
}
public class de_serializationProg2 {
	public static void print_data(emp obj1)
	{
		System.out.print("Name is : "+obj1.name);
		System.out.print(" Age is : "+obj1.age);
		System.out.print(" value of a is : "+obj1.a);
		System.out.print(" value of b is : "+obj1.b);
	}
	public static void main(String[] args)
	{
	emp obj1=new emp("Sonali ",24 ,12 ,2000);
	try
	{
		FileOutputStream fos=new FileOutputStream("serial1.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(obj1);
		

		oos.close();
		fos.close();
		System.out.println("Object has been serialized\n" + "Data before Deserialization."); 
		print_data(obj1); 
		obj1.b=666;
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
	emp obj2=null;
	try
	{
		FileInputStream fis=new FileInputStream("serial1.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		obj2=(emp)ois.readObject();
		ois.close();
		fis.close();
		print_data(obj1); 
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
	}
}
