import java.util.Scanner;
enum Day
{
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;
}
public class TestEnum
{
	Day day;
	public TestEnum(Day day)
	{
		this.day=day;
	}
	public void dayislike()
	{
		switch (day) 
        { 
        case MONDAY: 
            System.out.println("Mondays are bad."); 
            break; 
        case FRIDAY: 
            System.out.println("Fridays are better."); 
            break; 
        case SATURDAY: 
        case SUNDAY: 
            System.out.println("Weekends are best."); 
            break; 
        default: 
            System.out.println("Midweek days are so-so."); 
            break; 
        } 
	}
	public static void main(String[] args)
	{
		String str="MONDAY";
		TestEnum t1=new TestEnum(Day.valueOf(str));
		t1.dayislike();
	}
}