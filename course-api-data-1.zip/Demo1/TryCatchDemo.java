
public class TryCatchDemo {
	public static void main(String[] args)
	{
		int ans=dosum(3,4);
		System.out.print("Ans is " +ans);
	}

@SuppressWarnings("finally")
public static int dosum(int a,int b)
{
	System.out.print("In func block:\n");
	try
	{
		int ab= 10/0;
		return -1;
	}
	catch(Exception ex)
	{
		return -2;
	}
	finally
	{
		return -3;
	}
}
}
