

public class CommadLineProgram {

	public static void main(String args[])
	{
		int length = args.length;
		
		System.out.print("Command Line Argument is "+length+" "+args[0]);
	}
}
