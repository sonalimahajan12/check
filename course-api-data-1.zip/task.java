import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

class MyThread extends Thread
{
    Do_Task t;
    public void start(Do_Task t)
    {
            
            this.t = t;
            super.start();
    }
    @Override
    public void run()
    {
        
        FileHandler handler = null;
        try {
            handler = new FileHandler("Time1.log");
        } catch (IOException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        Logger logger = Logger.getLogger("task");
        logger.addHandler(handler);     
        logger.log(Level.INFO, "start time of  inc_pattern Methods is == {0}ms",t.inc_s);
        logger.log(Level.INFO, "end time of  inc_pattern Methods is == {0}ms",t.inc_e);
        logger.log(Level.INFO, "time Difference for inc_pattern method is == {0}ms",(t.inc_e - t.inc_s));
        logger.log(Level.INFO, "start time of  dec_pattern Methods is == {0}ms",t.dec_s);
        logger.log(Level.INFO, "end time of  dec_pattern Methods is == {0}ms",t.dec_e);
        logger.log(Level.INFO, "time Difference for dec_pattern method is == {0}ms",(t.dec_e - t.dec_s));
        logger.log(Level.INFO, "calculated time by both Methods == {0}ms", (t.inc_e - t.inc_s)+(t.dec_e - t.dec_s));
        logger.log(Level.INFO, "start time of  main Methods is == {0}ms",t.start);
        logger.log(Level.INFO, "end time of  main Methods is == {0}ms",t.end);
        logger.log(Level.INFO, " calculated time by main method== {0}ms", (t.end - t.start));
        logger.log(Level.INFO, "Time Difference == {0}ms", (t.end - t.start)-((t.inc_e - t.inc_s)+(t.dec_e - t.dec_s)));
    }
}
class Do_Task
{
    int n;
    long inc_s,inc_e;
    long dec_s,dec_e;
    long start,end;
    Do_Task(int n)
    {
        this.n = n;
    }
    public void inc_pattern()
    {
        inc_s = System.currentTimeMillis(); 
        for (int i=0; i<=n-1; i++) 
            {  
             for (int j=n-1; j>=i+1; j--)
            { 
                System.out.print(" "); 
            } 
            for(int k = 0; k<=i; k++)
            {
              System.out.print("*"+" ");
            }
            System.out.println();
            }
        inc_e = System.currentTimeMillis(); 
    }
    public void dec_pattern()
    {
        dec_s = System.currentTimeMillis(); 
          for (int i=0; i<=n-1; i++) 
            {  
             for (int j=0; j<=i; j++)
            { 
                System.out.print(" "); 
            } 
            for(int k = 0; k<=n-1-i; k++)
            {
              System.out.print("*"+" ");
            }
            System.out.println();                   
            }
        dec_e = System.currentTimeMillis(); 
    }
}
public class task	
{  
    public static void main(String args[]) throws IOException
    {
        long s = System.currentTimeMillis();
        MyThread t1 = new MyThread();
        t1.setDaemon(true);
        Do_Task t = new Do_Task(10); 
        t1.start(t);
        t.inc_pattern();
        t.dec_pattern();
        t.start = s;
        long e = System.currentTimeMillis(); 
        t.end = e;
        try{Thread.sleep(10000);}
        catch(Exception ex){}
    } 
}