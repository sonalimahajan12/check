package com.example.Sieve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SieveApplicationTests {

	@Test
	void contextLoads() {
	}

}
