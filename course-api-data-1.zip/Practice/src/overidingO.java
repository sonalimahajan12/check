class First
{
	int s=1000;
	public int salary()
	{
		return s;
	}
}
class Second extends First
{
	public int salary()
	{
		return s+1000;
	}
}
class Third extends First
{
	public int salary()
	{
		return s+4000;
	}
}
public class overidingO 
{
	static void showsalary(First e)
	{
		System.out.print("salary is " +e.salary());
	}
	public static void main(String[] args) 
	{
		First obj1=new Second();
		showsalary(obj1);
		First obj2=new Third();
		showsalary(obj2);
	}

}
