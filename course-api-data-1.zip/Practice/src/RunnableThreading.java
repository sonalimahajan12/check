class MultiThread implements Runnable
{
	public void run()
	{
		try 
		{
			System.out.print(" \n I'm in runnable interface  ");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
public class RunnableThreading {

	public static void main(String[] args) 
	{
		System.out.print("In Main");
		for(Integer i=0;i<3;i++)
		{
		Thread obj=new Thread(new MultiThread());
//		obj.start();
		}
	}

}
