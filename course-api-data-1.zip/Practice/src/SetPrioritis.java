class MyThread1 implements Runnable{
    List l = null;
     
    public MyThread1(List l) {
        super();
        this.l = l;
    }
 
    @Override
    public void run() {
        Iterator iter = l.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
            try {
                Thread.sleep(7000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
 
class MyThread2 implements Runnable{
    List l = null;
     
    public MyThread2(List l) {
        super();
        this.l = l;
    }
 
    @Override
    public void run() {
        Iterator iter = l.iterator();
        if(iter == null){
            System.exit(1);
        }
        while(iter.hasNext()){
            iter.remove();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
 
 
public class JavaTest{
    public static void main(String a[]){
        List<Integer> list = new ArrayList<Integer>();
        list.add(new Integer(1));
        list.add(new Integer(2));
        list.add(new Integer(3));
        list.add(new Integer(4));
        list.add(new Integer(5));
        list.add(new Integer(6));
        list.add(new Integer(7));
        list.add(new Integer(9));
        list.add(new Integer(10));
        list.add(new Integer(11));
         
        Thread t1 = new Thread(new MyThread1(list));
        Thread t2 = new Thread(new MyThread2(list));
 
        t1.setName("Thread_1");
        t2.setName("Thread_2");
         
        t1.start();
        t2.start();     
    }
}