class FirstThread extends Thread
{
	public void run()
	{
		try 
		{
			System.out.print("\nI'm in first Thread ");
			for(Integer i=0;i<100;i++)
				System.out.print(+i+ " ");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();	
		}
	}
}
class SecondThread extends Thread
{
	public void run()
	{
		try 
		{
			System.out.print("\nI'm in second Thread ");
			for(Integer i=0;i<100;i++)
				System.out.print(+i+ " ");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();	
		}
	}
}
class ThirdThread extends Thread
{
	public void run()
	{
		try 
		{
			System.out.print("\nI'm in third Thread ");
			for(Integer i=0;i<100;i++)
				System.out.print(+i+ " ");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();	
		}
	}
}
public class MultipleThreads 
{
	public static void main(String[] args) throws InterruptedException
	{
		Thread obj4=new Thread(new FirstThread());
		Thread obj1=new Thread(new SecondThread());
		Thread obj2=new Thread(new ThirdThread());
		obj4.start();
		obj1.start();
		obj2.start();
		obj4.join();
//		obj1.join();
//		obj2.join();
		
	}
}
