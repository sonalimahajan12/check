package com.mahajan.SpringAnno;

public interface MobileProcessor {
	void process();
}
