package com.mahajan.SpringAnno;

import java.text.Annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext factory=new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	samsung s7=factory.getBean(samsung.class);	//samsung s7=new samsung();
    	s7.config();
    			
        //System.out.println( "Hello World!" );
    }
}
