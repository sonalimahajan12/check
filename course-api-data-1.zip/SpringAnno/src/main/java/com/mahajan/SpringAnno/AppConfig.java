package com.mahajan.SpringAnno;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.mahajan.SpringAnno")
public class AppConfig {
	
//	@Bean
//	public samsung getPhone()
//	{
//		return new samsung();
//	}
//	
//	@Bean
//	public MobileProcessor getProcessor()
//	{
//		return new snapdragon();
//	}

}
