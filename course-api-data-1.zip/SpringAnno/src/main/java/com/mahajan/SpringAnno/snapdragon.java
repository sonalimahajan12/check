package com.mahajan.SpringAnno;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class snapdragon implements MobileProcessor {

	public void process() {
		System.out.println("Snapdragon World Best CPU\n");

	}

}
