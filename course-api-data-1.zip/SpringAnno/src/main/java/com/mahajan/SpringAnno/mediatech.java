package com.mahajan.SpringAnno;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class mediatech {
	public void process() {
		System.out.println("Media Tech Class");
	}
}
