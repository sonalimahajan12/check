package com.example.springstart.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.Null;

import org.springframework.stereotype.Service;

@Service
public class TopicService {
	
	private TopicRepository topicRepository;
	
//	 private List<Topic> topics= new ArrayList<Topic>(Arrays.asList(new Topic(1,"Sonali","Spring Framework Description"),
//				 new Topic(2,"Mahajan","STL"),
//				 new Topic(3,"Sonali","Django")));
//	
//	
//	
	
//	 HashMap<Integer, List<String>> topics=new HashMap<>();
//	 topics.put(1,Arrays.asList(new String[] {"Sonali","Spring Framework"}));

	
	
	 
	 public List<Topic> getallTopics()
	 {
		 List<Topic> topics=new ArrayList<>();
	 topicRepository.findAll().forEach(topics::add);
	 return topics;
	 }
	 
	 
	 public Optional<Topic> getTopic(Integer id) {
		 return topicRepository.findById(id);
//		 return topics.stream().filter(t-> t.getId().equals(id)).findFirst().get();
		
	}
	public void addtopic(Topic topic) {
		topicRepository.save(topic);
	}
	public void updateTopic(Integer id,Topic topic) {
		topicRepository.save(topic);
//		for(int j=0;j<topics.size();j++)
//		{
//			Topic t=topics.get(j);
//			if(t.getId().equals(id))
//			{
//				topics.set(j,topic);
//			return;
//			}
//		}		
	}
	public void deleteTopic(Integer id) {
		topicRepository.deleteById(id);
//		topics.removeIf(t->t.getId().equals(id));
		
	}
	 

}
