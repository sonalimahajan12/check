package io.sonali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseApiData1Application {

	public static void main(String[] args) {
		SpringApplication.run(CourseApiData1Application.class, args);
	}

}
