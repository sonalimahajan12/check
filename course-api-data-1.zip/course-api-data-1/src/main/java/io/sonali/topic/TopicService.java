package io.sonali.topic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TopicService {
	
	@Autowired
	private TopicRepository topicRepository;
	
//	 private List<Topic> topics= new ArrayList<Topic>(Arrays.asList(new Topic("Java","Sonali","Spring Framework Description"),
//				 new Topic("C++","Mahajan","STL"),
//				 new Topic("Python","Sonali","Django")));
	 
	
	
	 
	 /**
	  * method to return 
	 * @return
	 */
	public Map<String, List<String>> getallTopics()
	 {
		 Map<String, List<String>>  returnMap = new HashMap<>();
		
		 List<Topic> topics=new ArrayList<>();
		 
		 topicRepository.findAll()
		 .forEach(topics::add);
		
		 
		 for( Topic topic: topics) {
			 List<String> innerMap=new ArrayList<>();
			 innerMap.add(topic.getName());
			 innerMap.add(topic.getDescription());
			// Map<String, String> innerMap=new HashMap<>();
			// innerMap.put(topic.getName(), topic.getDescription());
			 returnMap.put(topic.getId(), innerMap);
		 }
		 
		 return returnMap;
	 }
	 
	 
	 public Map<String, List<String>> getTopic(String id) {
		 	Map<String, List<String>>  returnMap = new HashMap<>();
		 	List<Topic> topics=new ArrayList<>();
	 		topicRepository.findById(id);
	 		List<String> dataTopic = returnMap.get(id);
//	 		for()
//	 		{
//	 			Topic tp=new Topic();
//	 			List<String> inners=new ArrayList<>();
//	 			inners.add(tp.getName());
//	 			inners.add(tp.getDescription());
//	 			returnMap.put(tp.getId(), inners);
//	 		}
	 		return dataTopic;
		// return topics.stream().filter(t-> t.getId().equals(id)).findFirst().get();
	}
	public void addtopic(Topic topic) {
		topicRepository.save(topic);
		//topics.add(topic);
		
	}
	public void updateTopic(String id,Topic topic) {
		topicRepository.save(topic);
//		for(int j=0;j<topics.size();j++)
//		{
//			Topic t=topics.get(j);
//			if(t.getId().equals(id))
//			{
//				topics.set(j,topic);
//			return;
//			}
//		}		
	}
	public void deleteTopic(String id) {
		//topics.removeIf(t->t.getId().equals(id));
		topicRepository.deleteById(id);
	}
	 

}
