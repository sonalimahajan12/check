package io.sonali.topic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ServiceLayer {
	
	HashMap<String, List<Topic>> map = new HashMap<>();

	Topic tpTopic=new Topic();
	public void storeToHashMap(String key,List<String> value)
	{
		
	
		map.put(tpTopic.getId(), value);
	}

}
