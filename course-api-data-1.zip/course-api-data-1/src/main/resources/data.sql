insert into topic
values('10001','Ranga', 'E1234567');

insert into topic
values('10002','Ravi', 'A1234568');

insert into topic
values('10003','Rajan', 'A1234533');


UPDATE topic SET id = '1010' WHERE name = 'A1234568';