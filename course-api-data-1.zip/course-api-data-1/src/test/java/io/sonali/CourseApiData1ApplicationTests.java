package io.sonali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseApiData1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
