package com.example.bootjpa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bootjpa.model.Alien;
import com.fasterxml.jackson.core.sym.Name;

@RestController
public class AlienController {
	
	
	@GetMapping("/test")
	public String Name()
	{
		return "Hello World";
	}
	
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
		
	}
	@RequestMapping("/addAlien")
	public String addAlien(Alien alien)
	{		
		return "home.jsp";
	}

}
