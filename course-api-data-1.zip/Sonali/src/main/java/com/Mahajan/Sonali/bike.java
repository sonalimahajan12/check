package com.Mahajan.Sonali;

import org.springframework.stereotype.Component;

@Component
public class bike implements vehicle {

		public void drive()
		{
			System.out.println("This is bike CLASS\n");
		}
}
