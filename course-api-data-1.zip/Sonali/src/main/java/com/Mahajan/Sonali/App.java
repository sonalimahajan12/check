package com.Mahajan.Sonali;

import javax.naming.Context;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	
    	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
    	
    	
    	car obj=(car) context.getBean("car");

    	
//    	vehicle obj=(vehicle) context.getBean("bike");
    	obj.drive();
    	
//    	Tyre tyre=(Tyre) context.getBean("Tyre");
//    	System.out.println(tyre);
//    	
    	
       // System.out.println( "Hello World!" );
    }
}
