package com.Mahajan.Sonali;

public interface vehicle 
{
void drive();

}
