package io.sonali.store;

import org.springframework.stereotype.Service;

@Service
public class StoreServiceLayer {
	
	public void perfromStore(Store str)
	{
		
	}

}
