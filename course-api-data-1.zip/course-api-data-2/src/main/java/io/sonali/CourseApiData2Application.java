package io.sonali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseApiData2Application {

	public static void main(String[] args) {
		SpringApplication.run(CourseApiData2Application.class, args);
	}

}
