
public class ThreadDeadlock {
	public static void main(String[] args)
	{
		try
		{
			System.out.print("Entering into deadlock\n");
			Thread.currentThread().join();
			System.out.print("it will never execute");
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

}
