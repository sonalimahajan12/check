import java.util.ArrayList;
import java.util.List;

public class testing {
	public static List<Integer> sendtofun(List<Integer> lst,Integer n)
	{
		 ArrayList<Integer> numbers = new ArrayList<Integer>();
		    numbers.add(5);
		    numbers.add(11);
		    numbers.add(3);
		    return(numbers);
	}
	public static void main(String[] args)
	{
		List<Integer> lst=new ArrayList<Integer>();
		Integer n=5;
		for(Integer j=1;j<=5;j++)
		{
			lst.add(j);
		}
		System.out.println("List is: " +lst);
		//sendtofun(lst,n);
		
		List<Integer> stuff = new testing().sendtofun(lst, n);
		System.out.println(stuff);
	}
	
}
