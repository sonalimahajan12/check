import java.io.*;

interface In1
{
	final int a=10;
	void display();
}
class InterfaceTest implements In1
{
	public void display()
	{
		System.out.println("Printed");
	}
	public static void main(String[] args)
	{
		InterfaceTest t=new InterfaceTest();
		t.display();
		System.out.println(a);
	}
}