import java.io.*;
import java.util.Scanner;
public class pattern
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int number=s.nextInt();
		for(int i=1;i<=number;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print("* " );
			}
			System.out.print("\n");
		}
		
	}
}