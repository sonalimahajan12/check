import java.io.*;
interface vehicle
{
	void changegear(int a);
	void applybrakes(int a);
	void speedup(int a);
}
class bicycle implements vehicle
{
	int gear;
	int speed;
	
	public void changegear(int newgear)
	{
		gear=newgear;
	}
	public void speedup(int increments)
	{
		speed+=increments;
	}
	public void applybrakes(int decrements)
	{
		speed+=decrements;
	}
	public void printstates()
	{
		System.out.println("Speed: "+ speed + " gear: " + gear );
	}
}
class bike implements vehicle
{
	int gear;
	int speed;
	public void changegear(int newgear)
	{
		gear=newgear;
	}
	public void speedup(int increments)
	{
		speed+=increments;
	}
	public void applybrakes(int decrements)
	{
		speed+=decrements;
	}
	public void printstates()    
	{
		System.out.println("Speed: "+ speed + " gear: " + gear);
	}
}
public class Interfacetest2
{
	public static void main(String[] args)
	{
		bicycle t1=new bicycle();
		System.out.println("Bicycle Present State");
		t1.changegear(2);
		t1.speedup(3);
		t1.applybrakes(1);
		t1.printstates();
		bike t2=new bike();
		System.out.println("Bike Present State");
		t2.changegear(1);
		t2.speedup(4);
		t2.applybrakes(3);
		t2.printstates();
	}
}