package co.sonali;

public class Client {

	public static void main(String[] args)
	{
		Employee employee=new Employee();
		employee.setId(101);
		employee.setEname("Sonali");
		employee.setEsalary(100000);
		System.out.println("\n Details are: "+employee);
		
		
		// Inversion of control
		
	}

}
