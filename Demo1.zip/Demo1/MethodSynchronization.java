class Line
{
	
}
public class MethodSynchronization {

}
