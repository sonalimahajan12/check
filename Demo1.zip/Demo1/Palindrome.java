import java.util.*;
class Palindrome
{
	public static void main(String[] args)
 	{
		int c=0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter sentence: ");
		String str = sc.nextLine();
		StringTokenizer stk = new StringTokenizer(str);
		while (stk.hasMoreTokens())
		{
			String w=stk.nextToken();
			StringBuffer sb = new StringBuffer(w);
			String rev = sb.reverse().toString();
			if (w.equalsIgnoreCase(rev))
				c++;
		}
		System.out.println("No of palindromes are: " + c);
	}
}