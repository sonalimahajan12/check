
public class genericFunctionsEg {
	
	static <T> void gendisplay(T obj)
	{
		System.out.print(obj.getClass().getName()+ "= " + obj);
	}
	
	public static void main(String[] args)
	{
		gendisplay(11);
		gendisplay("Sonali Mahajan");
		gendisplay(1.0);
	}
}
