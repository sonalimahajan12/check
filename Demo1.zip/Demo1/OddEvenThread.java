
class EvenThread implements Runnable
{
	public void run()
	{
		try
		{
			for(int i=1;i<=100;i++)
			{
				if(i%2==0)
					System.out.print("\nEven no is : "+ i );
			}
		}
		catch(Exception e)
		{
			System.out.print("\nException occured\n");
		}
	}
}
class OddThread implements Runnable
{
	public void run()
	{
		try
		{
			for(int i=1;i<=100;i++)
			{
				if(i%2!=0)
					System.out.print("\nOdd no is : "+ i );
			}
		}
		catch(Exception e)
		{
			System.out.print("\nException occured\n");
		}
	}
}
public class OddEvenThread {
	public static void main(String[] args) throws InterruptedException
	{
		Thread obj1=new Thread(new EvenThread());
		Thread obj2=new Thread(new OddThread());
		obj1.start();
		obj1.join();
		
		obj2.start();
		
		
		
		
	}
}
