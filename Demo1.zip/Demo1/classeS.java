import java.util.*;
import java.io.*;
import java.lang.*;

class A
{
	public void printfirst()
	{
		System.out.print("Hello");
	}
}
class B extends A
{
	public void printsecond()
	{
		System.out.print("Java");
	}
}
public class classeS
{
	public static void main(String[] args)
	{
		B obj=new B();
		obj.printfirst();
		obj.printsecond();
		obj.printfirst();
	}
}