import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class FindMax implements Callable<Integer> {
	private List<Integer> lst;

	public FindMax(List<Integer> lst) {
		this.lst = lst;
	}

	@Override
	public Integer call() throws Exception {
		Thread.sleep(1000);
		Integer maxOfList = Collections.max(lst);
		return maxOfList;
	}
}

public class Task_Java {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		int numberOfParts;
		List<Integer> arrayList = new ArrayList<>();
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the No of Elements in List: ");
		n = sc.nextInt();
		System.out.print("Enter the List: ");
		for (int i = 0; i < n; i++) {
			int input = sc.nextInt();
			arrayList.add(input);
		}
		System.out.print("Enter No of Sublist: ");
		numberOfParts = sc.nextInt();
		// Final Sub-List
		subListRet(arrayList, numberOfParts);
		
		sc.close();
	}

	public static void subListRet(List<Integer> arrayList, Integer numberOfParts)
			throws InterruptedException, ExecutionException {
		List<List<Integer>> DividSublist = new ArrayList<>(numberOfParts);
		// Dynamic Thread
		ExecutorService executorService = Executors.newFixedThreadPool(numberOfParts);
		int size = arrayList.size();
		int sizePernumberOfParts = (int) Math.ceil(((double) size) / numberOfParts);
		int leftElements = size;
		int i = 0;
		while (i < size && numberOfParts != 0) {
			DividSublist.add((List<Integer>) arrayList.subList(i, i + sizePernumberOfParts));
			i = i + sizePernumberOfParts;
			leftElements = leftElements - sizePernumberOfParts;
			sizePernumberOfParts = (int) Math.ceil(((double) leftElements) / --numberOfParts);
		}
//		    return(DividSublist);
		List<Integer> fnres = new ArrayList<>();

		// start
		long st = System.currentTimeMillis();
		for (List<Integer> s : DividSublist) {
			System.out.println("\n Sublist is: " + s);
			Future resultmx = executorService.submit(new FindMax(s));
			// System.out.println("\n Calling get method ");
			Integer res = (Integer) resultmx.get();
			fnres.add(res);
		}
		long end = System.currentTimeMillis();
		// end
		System.out.println("\nTime taken " + (end - st) + " ms"); // diff
		System.out.println("\nTop max is: " + Collections.max(fnres));
		List<Future<Integer>> resultList = new ArrayList<>();
		List<Integer> smIntegers = new ArrayList<>();

		long st1 = System.currentTimeMillis();
		for (List<Integer> s : DividSublist) {
			FindMax calculator = new FindMax(s);
			System.out.println("\n Sublist is: " + s);
			Future<Integer> result = executorService.submit(calculator);
			resultList.add(result);
		}
		for (Future<Integer> future : resultList) {
			try {
				System.out.println("\n Maximum is = " + future.get());
				smIntegers.add(future.get());
			//} catch (InterruptedException | ExecutionException e) {
			} catch (Exception e){
				e.printStackTrace();
			}
		}
		long end1 = System.currentTimeMillis();
		System.out.println("\nTime taken " + (end1 - st1) + " ms");
		System.out.println("\nTop max is: " + Collections.max(smIntegers));
		executorService.shutdown(); 
	}
}
