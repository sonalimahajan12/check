
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class Solution {
	
	public static <T> void main(String[] args) {
			
		List<String> arrayList = new ArrayList<String>();
	    for (int i = 0; i < 26; i++) {
	        arrayList.add(String.valueOf(i));
	    }
	    int numberOfParts=17;
	    List<List<T>> numberOfPartss = new ArrayList<>(numberOfParts);
	      int size = arrayList.size();
	      int sizePernumberOfParts = (int) Math.ceil(((double) size) / numberOfParts);
	      int leftElements = size;
	      int i = 0;
	      while (i < size && numberOfParts != 0) {
	          numberOfPartss.add((List<T>) arrayList.subList(i, i + sizePernumberOfParts));
	          i = i + sizePernumberOfParts;
	          leftElements = leftElements - sizePernumberOfParts;
	          sizePernumberOfParts = (int) Math.ceil(((double) leftElements) / --numberOfParts);
	       }
	       System.out.println(numberOfPartss);
	    


	    }
}


